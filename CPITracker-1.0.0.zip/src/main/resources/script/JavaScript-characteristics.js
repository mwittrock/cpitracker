importClass(com.sap.gateway.ip.core.customdev.util.Message);

function addJavaScriptCharacteristics(message) {
    var engine = org.mozilla.javascript.Context.getCurrentContext().getImplementationVersion();
    message.setProperty("cpitracker.javascript.engine", engine);
    return message;
}