import com.sap.it.script.v2.api.Message

def Message addGroovyCharacteristicsVersion2x(Message message) {
    // Supposed to run in the version 2.x Script step.
    message.setProperty('cpitracker.groovy.version.v2x', GroovySystem.version)
    return message
}