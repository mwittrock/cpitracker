<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:sap="http://sap.com/it/" exclude-result-prefixes="sap">
	<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes"/>
	<xsl:param name="exchange"/>
	<xsl:template match="/">
		<!-- Set the properties we need. -->
		<xsl:value-of select="sap:setProperty($exchange, 'cpitracker.xslt.version', system-property('xsl:version'))"/>
		<xsl:value-of select="sap:setProperty($exchange, 'cpitracker.xslt.vendor', system-property('xsl:vendor'))"/>
		<xsl:value-of select="sap:setProperty($exchange, 'cpitracker.xslt.product', system-property('xsl:product-name'))"/>
		<xsl:value-of select="sap:setProperty($exchange, 'cpitracker.xslt.product.version', system-property('xsl:product-version'))"/>
		<unimportant-payload/>
	</xsl:template>
</xsl:stylesheet>