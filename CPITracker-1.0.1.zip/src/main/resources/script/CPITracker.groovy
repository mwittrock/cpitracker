import static Constants.*

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder
import groovy.util.XmlSlurper
import org.osgi.framework.FrameworkUtil
import java.time.Instant
import java.time.format.DateTimeFormatter

class Constants {
    public static final String PROPERTY_PREFIX = 'cpitracker.'
    public static final String PREVIOUS_CHARACTERISTICS_MAP = 'PreviousValues'
    public static final String CURRENT_CHARACTERISTICS_MAP = 'CurrentValues'
    public static final String ASSUMED_BUNDLE_CLASS = 'com.sap.gateway.ip.core.customdev.util.Message'
    public static final String VERSION_BUNDLE_NAME = 'com.sap.it.node.stack.profile'
}

readableCharacteristics = [
    'xslt.version': 'The supported XSLT version',
    'xslt.vendor': 'The XSLT processor vendor',
    'xslt.product': 'The XSLT processor',
    'xslt.product.version': 'The XSLT processor version',
    'java.version': 'The Java runtime version',
    'java.vendor': 'The Java runtime vendor',
    'java.vm.version': 'The Java Virtual Machine version',
    'java.vm.vendor': 'The Java Virtual Machine vendor',
    'camel.version': 'The Apache Camel version',
    'groovy.version': 'The Groovy version',
    'sap-cloud-integration.version': 'The SAP Cloud Integration version number',
    'sap-cloud-integration.runtime.version': 'The SAP Cloud Integration runtime version number',
    'javascript.engine': 'The JavaScript engine'
]

def Message createUpdatesDocument(Message message) {
    /*
     * This method is where updates are detected. We compare the characteristics gathered in the current run with the
     * ones gathered in the previous one. Specifically, an update has occurred if the current value of a characteristic
     * is different from its previous value. Characteristics and their values are stored in two Exchange properties in
     * Maps (one for the current run and one for the previous run). The detected updates are added to an XML document
     * which replaces the current message body.
     */
    def prevCharacteristicsMap = message.getProperty(PREVIOUS_CHARACTERISTICS_MAP)
    def currCharacteristicsMap = message.getProperty(CURRENT_CHARACTERISTICS_MAP)

    def sw = new StringWriter()
    def builder = new MarkupBuilder(sw)

    // The single quotes in the following prevent MarkupBuilder from failing on element names containing hyphens.
    builder.updates {
        'discovered'(DateTimeFormatter.ISO_INSTANT.format(Instant.now()))
        prevCharacteristicsMap.each { c, v -> 
            currVal = currCharacteristicsMap.get(c)
            if (currVal != v) {
                update {
                    'characteristic'(c)
                    'characteristic-readable'(readableCharacteristics[c])
                    'previous-value'(v)
                    'current-value'(currVal)
                }
            }
        }
    }

    message.setBody(sw.toString())
    return message
}

def Message createCharacteristicsDocument(Message message) {
    /*
     * This method generates an XML document containing all the characteristics we've gathered and replaces the current
     * message body with it. Each characteristic is stored as an Exchange property. These properties can be recognized
     * by their prefix, which is what happens in the if statement in the following.
     */
    def sw = new StringWriter()
    def builder = new MarkupBuilder(sw)

    builder.characteristics {
        message.getProperties().each { p, v ->
            if (p.startsWith(PROPERTY_PREFIX)) {
                characteristic {
                    name(p.substring(PROPERTY_PREFIX.length()))
                    value(v as String)
                }
            }
        }
    }

    message.setBody(sw.toString())
    return message
}

def Message addGroovyCharacteristics(Message message) {
    message.setProperty(PROPERTY_PREFIX + 'groovy.version', GroovySystem.version)
    return message
}

def Message addJavaCharacteristics(Message message) {
    /*
     * The following list contains the Java system properties we are interested in. Please note that we reuse the
     * system property name as the characteristic name.
     */
    def javaSystemProperties = ['java.version', 'java.vendor', 'java.vm.version', 'java.vm.vendor']
    javaSystemProperties.each { p -> 
        message.setProperty(PROPERTY_PREFIX + p, System.getProperty(p))
    }
    return message
}

def Message addCloudIntegrationCharacteristics(Message message) {
    /*
     * The approach to programmatically determining the SAP Cloud Integration version number is described in detail in
     * this SAP Community blog post:
     *
     * https://community.sap.com/t5/technology-blogs-by-members/hcitracker-is-now-cpitracker/ba-p/13375329
     *
     * Following this approach, we end up with an OSGi bundle. On Neo (which is where the original CPITracker project
     * was developed), the version number of this bundle is equal to the SAP Cloud Integration version number. However,
     * on Cloud Foundry this is not the case. Instead, the bundle's version number equals the SAP Cloud Integration
     * runtime version. At the moment, we do not have a way to programmatically determine the version number of SAP
     * Cloud Integration on Cloud Foundry.
     *
     * None of this is documented, and there is no official API to get those version numbers. For that reason, we throw
     * an AssertionError in the following, if an assumption does not hold. 
     *
     * First off, get a Bundle object using a class assumed to belong to a bundle.
     */
    def entryBundle = FrameworkUtil.getBundle(Class.forName(ASSUMED_BUNDLE_CLASS))
    if (entryBundle == null) {
        throw new AssertionError("No OSGi bundle for class ${ASSUMED_BUNDLE_CLASS}")
    }
    // Get all bundles via that initial bundle's BundleContext.
    def allBundles = entryBundle.getBundleContext().getBundles()
    // Find the version bundle by symbolic name (a getBundleByName method in BundleContext would have been nice).
    def versionBundle = allBundles.find() { b -> b.getSymbolicName() == VERSION_BUNDLE_NAME }
    if (versionBundle == null) {
        throw new AssertionError("No OSGi bundle with symbolic name ${VERSION_BUNDLE_NAME} exists")
    }
    /*
     * If we are on Neo, the version number of this bundle equals the SAP Cloud Integration version. On Cloud Foundry,
     * it equals the SAP Cloud Integration runtime version. This is why we use two different characteristic names in the
     * following.
     */
    def characteristicName = runningOnCloudFoundry() ? 'sap-cloud-integration.runtime.version' : 'sap-cloud-integration.version'
    message.setProperty(PROPERTY_PREFIX + characteristicName, versionBundle.getVersion())
    return message
}

def Message storePreviousCharacteristics(Message message) {
    storeCharacteristics(message, PREVIOUS_CHARACTERISTICS_MAP)
    return message
}

def Message storeCurrentCharacteristics(Message message) {
    storeCharacteristics(message, CURRENT_CHARACTERISTICS_MAP)
    return message
}

void storeCharacteristics(Message message, String propertyName) {
    message.setProperty(propertyName, xmlToMap(message.getBody(Reader)))
}

Map<String, String> xmlToMap(Reader xml) {
    /*
     * This method parses the characteristics XML document, stores each characteristic and its value in a Map and
     * returns that Map.
     */
    def characteristicsMap = new HashMap<String, String>()
    def characteristics = new XmlSlurper().parse(xml)
    characteristics.characteristic.each { c ->
        characteristicsMap.put(c.name.text(), c.value.text())
    }
    return characteristicsMap
}

boolean runningOnCloudFoundry() {
    // Assumption: The VCAP_APPLICATION environment variable is present if and only if we are running on Cloud Foundry.
    return System.getenv('VCAP_APPLICATION') != null
}